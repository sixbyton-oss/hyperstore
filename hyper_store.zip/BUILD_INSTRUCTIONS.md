# Hyper Store - Build & Deployment Instructions

## 📦 What You Downloaded

You have downloaded the **complete source code** for Hyper Store. This is a modern React + Vite application that needs to be **built** before deployment.

---

## 🚀 Quick Deployment Guide

### Step 1: Extract the ZIP File
```bash
unzip hyper-store-backup.zip
cd hyper-store-backup
```

### Step 2: Install Dependencies
Make sure you have **Node.js 18+** installed, then run:
```bash
npm install
```

### Step 3: Build for Production
```bash
npm run build
```

This creates a `/dist` folder with optimized, deployable files.

### Step 4: Deploy the /dist Folder
Upload the entire `/dist` folder to any static hosting service:

- **Netlify**: Drag & drop the `/dist` folder
- **Vercel**: `vercel --prod` (after installing Vercel CLI)
- **GitHub Pages**: Push `/dist` to `gh-pages` branch
- **Any Web Server**: Upload `/dist` contents to your web root

---

## 🌐 Hosting Options

### Option 1: Netlify (Easiest)
1. Go to https://app.netlify.com/drop
2. Drag the `/dist` folder into the upload area
3. Your site is live instantly!

### Option 2: Vercel
```bash
npm install -g vercel
vercel --prod
```

### Option 3: Traditional Web Hosting
1. Build the project: `npm run build`
2. Upload `/dist` folder contents via FTP/SFTP
3. Point your domain to the uploaded files

---

## 🔧 Development Mode (Optional)

To run the app locally for testing/editing:
```bash
npm run dev
```

Visit `http://localhost:5173` in your browser.

---

## 📋 What's Inside

- **src/**: All React components, pages, and logic
- **public/**: Static assets (images, logos)
- **supabase/**: Backend Edge Functions
- **tailwind.config.js**: Styling configuration
- **vite.config.ts**: Build configuration
- **package.json**: Dependencies and scripts

---

## ⚠️ Important Notes

1. **Supabase Configuration**: If you're deploying to a new environment, you'll need to set up your own Supabase project and update the credentials in `src/db/supabase.ts`.

2. **Environment Variables**: Create a `.env` file if you need custom API keys:
   ```
   VITE_SUPABASE_URL=your_supabase_url
   VITE_SUPABASE_ANON_KEY=your_anon_key
   ```

3. **TikTok Downloader**: The TikTok download feature uses Supabase Edge Functions. Make sure to deploy those functions to your Supabase project.

---

## 🆘 Troubleshooting

**Problem**: `npm install` fails
- **Solution**: Make sure you have Node.js 18+ installed. Download from https://nodejs.org/

**Problem**: Build fails with errors
- **Solution**: Delete `node_modules` and `package-lock.json`, then run `npm install` again

**Problem**: Site works locally but not after deployment
- **Solution**: Make sure you deployed the `/dist` folder contents, not the source code

---

## 📞 Need Help?

If you encounter issues:
1. Check that Node.js version is 18 or higher: `node --version`
2. Clear cache: `npm cache clean --force`
3. Reinstall: `rm -rf node_modules package-lock.json && npm install`

---

## 🎉 You're All Set!

Your Hyper Store backup is safe and ready to deploy anywhere. Follow the steps above to get your site live on any hosting platform.

**Built with ❤️ using React + Vite + Tailwind CSS + Supabase**
