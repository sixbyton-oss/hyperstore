export const getVisitorCount = (): number => {
  const count = localStorage.getItem('hyperstore-visitor-count');
  return count ? parseInt(count, 10) : 9; // Start at 9, so first visitor makes it 10
};

export const incrementVisitorCount = (): number => {
  const currentCount = getVisitorCount();
  const newCount = currentCount + 1;
  localStorage.setItem('hyperstore-visitor-count', newCount.toString());
  return newCount;
};

export const initializeVisitorTracking = (): number => {
  const hasVisited = sessionStorage.getItem('hyperstore-visited-this-session');
  
  if (!hasVisited) {
    sessionStorage.setItem('hyperstore-visited-this-session', 'true');
    return incrementVisitorCount();
  }
  
  return getVisitorCount();
};
