import React, { createContext, useContext, useEffect, useState } from 'react';

export type Theme = 'light' | 'dark' | 'neon' | 'pink' | 'green' | 'blue' | 'christmas' | 'newyear' | 'summer';

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  isChangingTheme: boolean;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<Theme>(() => {
    const saved = localStorage.getItem('hyperstore-theme');
    return (saved as Theme) || 'light';
  });
  const [isChangingTheme, setIsChangingTheme] = useState(false);

  useEffect(() => {
    localStorage.setItem('hyperstore-theme', theme);
    const root = window.document.documentElement;
    root.classList.remove('light', 'dark', 'neon', 'pink', 'green', 'blue', 'christmas', 'newyear', 'summer');
    root.classList.add(theme);
  }, [theme]);

  const setTheme = (newTheme: Theme) => {
    setIsChangingTheme(true);
    setTimeout(() => {
      setThemeState(newTheme);
      setTimeout(() => {
        setIsChangingTheme(false);
      }, 1000);
    }, 500);
  };

  return (
    <ThemeContext.Provider value={{ theme, setTheme, isChangingTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) throw new Error('useTheme must be used within ThemeProvider');
  return context;
};
