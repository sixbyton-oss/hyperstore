import React, { lazy, Suspense } from 'react';
import type { ReactNode } from 'react';
import { Home } from './pages/Home';
import { ModApksPage } from './pages/ModApksPage';
import { DetailPage } from './pages/DetailPage';
import { SearchPage } from './pages/SearchPage';
import { ProfilePage } from './pages/ProfilePage';
import { SettingsPage } from './pages/SettingsPage';
import { TikTokPage } from './pages/TikTokPage';
import { Skeleton } from '@/components/ui/skeleton';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
}

const LoadingSkeleton = () => (
  <div className="space-y-8 animate-pulse p-8">
    <Skeleton className="h-[400px] w-full rounded-3xl bg-muted" />
    <div className="grid grid-cols-6 gap-6">
      {[1, 2, 3, 4, 5, 6].map(i => <Skeleton key={i} className="aspect-square rounded-2xl bg-muted" />)}
    </div>
  </div>
);

const routes: RouteConfig[] = [
  {
    name: 'Home',
    path: '/',
    element: <Suspense fallback={<LoadingSkeleton />}><Home /></Suspense>
  },
  {
    name: 'Mod APKs',
    path: '/mod-apks',
    element: <Suspense fallback={<LoadingSkeleton />}><ModApksPage /></Suspense>
  },
  {
    name: 'TikTok Downloader',
    path: '/tiktok',
    element: <Suspense fallback={<LoadingSkeleton />}><TikTokPage /></Suspense>
  },
  {
    name: 'Search',
    path: '/search',
    element: <Suspense fallback={<LoadingSkeleton />}><SearchPage /></Suspense>
  },
  {
    name: 'Profile',
    path: '/profile',
    element: <Suspense fallback={<LoadingSkeleton />}><ProfilePage /></Suspense>
  },
  {
    name: 'Settings',
    path: '/settings',
    element: <Suspense fallback={<LoadingSkeleton />}><SettingsPage /></Suspense>
  },
  {
    name: 'App Detail',
    path: '/app/:id',
    element: <Suspense fallback={<LoadingSkeleton />}><DetailPage /></Suspense>
  }
];

export default routes;
