import React, { useState } from 'react';
import { useProfile } from '@/contexts/ProfileContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { toast } from 'sonner';
import { User, Mail, Camera, Save, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const ProfilePage: React.FC = () => {
  const { profile, updateProfile } = useProfile();
  const navigate = useNavigate();
  const [formData, setFormData] = useState(profile);
  const [loading, setLoading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 1024 * 1024) {
        toast.error('Image too large. Please select a file under 1MB.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, avatar: reader.result as string }));
        toast.success('Avatar updated locally');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate API delay
    setTimeout(() => {
      updateProfile(formData);
      setLoading(false);
      toast.success('Profile updated successfully!');
    }, 800);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-fade-in">
      <header className="flex items-center gap-4">
        <Button variant="ghost" size="icon" className="rounded-full" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-3xl font-black">Edit Profile</h1>
      </header>

      <Card className="border-none shadow-xl rounded-3xl overflow-hidden bg-card/80 backdrop-blur-md">
        <CardHeader className="pb-4">
          <CardTitle className="text-2xl">Personal Information</CardTitle>
          <CardDescription>Update your profile details and avatar.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="flex flex-col items-center gap-6 py-6 border-b">
              <div className="relative group">
                <Avatar className="w-32 h-32 md:w-40 md:h-40 border-4 border-background shadow-2xl">
                  <AvatarImage src={formData.avatar} className="object-cover" />
                  <AvatarFallback className="text-4xl font-black bg-muted">
                    {formData.name?.[0]?.toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
                <label className="absolute bottom-2 right-2 p-3 bg-primary text-primary-foreground rounded-full shadow-xl cursor-pointer hover:scale-110 transition-transform hover:shadow-primary/40">
                  <Camera className="w-6 h-6" />
                  <input type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
                </label>
              </div>
              <p className="text-xs text-muted-foreground uppercase tracking-widest font-bold">Recommended size: 512x512</p>
            </div>

            <div className="space-y-6">
              <div className="space-y-2 group">
                <Label htmlFor="name" className="text-sm font-black uppercase tracking-widest text-muted-foreground/80 flex items-center gap-2 px-1">
                  <User className="w-4 h-4 text-primary" /> Full Name
                </Label>
                <Input
                  id="name"
                  placeholder="e.g. Alex Johnson"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="h-14 rounded-2xl border-2 focus-visible:ring-primary/10 focus-visible:border-primary transition-all text-lg font-medium"
                />
              </div>

              <div className="space-y-2 group">
                <Label htmlFor="email" className="text-sm font-black uppercase tracking-widest text-muted-foreground/80 flex items-center gap-2 px-1">
                  <Mail className="w-4 h-4 text-primary" /> Email Address
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="e.g. alex@example.com"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  className="h-14 rounded-2xl border-2 focus-visible:ring-primary/10 focus-visible:border-primary transition-all text-lg font-medium"
                />
              </div>
            </div>

            <Button type="submit" disabled={loading} className="w-full h-16 rounded-2xl text-xl font-black shadow-lg shadow-primary/20 transition-all hover:scale-[1.02] active:scale-95">
              {loading ? 'Saving Changes...' : (
                <>
                  <Save className="mr-3 w-6 h-6" /> Save Profile
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};
