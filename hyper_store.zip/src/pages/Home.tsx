import React, { useEffect, useState } from 'react';
import { Banner } from '@/components/store/Banner';
import { AppCard } from '@/components/store/AppCard';
import { featuredApps, mockApps } from '@/data/mockData';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { ChevronRight, Zap, Download, Sparkles, Info } from 'lucide-react';
import { HyperBrand } from '@/components/common/Brand';
import { initializeVisitorTracking } from '@/utils/visitorTracking';

export const Home: React.FC = () => {
  const [visitorCount, setVisitorCount] = useState(0);
  const [totalApps, setTotalApps] = useState(0);

  useEffect(() => {
    const count = initializeVisitorTracking();
    setVisitorCount(count);
    
    // Get total apps count from localStorage, default to 0
    const storedAppsCount = localStorage.getItem('hyperstore-total-apps');
    const appsCount = storedAppsCount ? parseInt(storedAppsCount, 10) : 0;
    setTotalApps(appsCount);
  }, []);

  return (
    <div className="space-y-16 animate-fade-in pb-12">
      <header className="flex flex-col md:flex-row items-center justify-between gap-8 py-10 border-b border-border/50">
        <div className="space-y-4 text-center md:text-left">
          <HyperBrand size="lg" className="hidden md:flex" />
          <h1 className="text-4xl md:text-6xl font-black tracking-tighter leading-none bg-gradient-to-r from-primary via-primary/80 to-accent bg-clip-text text-transparent italic">
            FREE PREMIUM DOWNLOADS
          </h1>
          <p className="text-muted-foreground text-lg md:text-xl font-medium max-w-xl">
            Get the best premium tools, modded apps, and social media downloaders for free. Everything you need in one place.
          </p>
        </div>
        <div className="flex gap-4">
           <div className="px-8 py-5 bg-card/50 backdrop-blur-md rounded-[2rem] border shadow-xl text-center min-w-[140px] hover:scale-105 transition-transform duration-300">
              <div className="text-4xl font-black text-primary mb-1">{visitorCount}</div>
              <div className="text-[10px] uppercase tracking-widest text-muted-foreground font-black">Live Visitors</div>
           </div>
           <div className="px-8 py-5 bg-card/50 backdrop-blur-md rounded-[2rem] border shadow-xl text-center min-w-[140px] hover:scale-105 transition-transform duration-300">
              <div className="text-4xl font-black text-accent mb-1">{totalApps}</div>
              <div className="text-[10px] uppercase tracking-widest text-muted-foreground font-black">Premium Mods</div>
           </div>
        </div>
      </header>

      <section>
        <div className="flex items-center gap-3 mb-8">
          <Sparkles className="w-8 h-8 text-yellow-400 fill-yellow-400 animate-pulse" />
          <h2 className="text-3xl font-black tracking-tight italic uppercase">Spotlight</h2>
        </div>
        <Banner apps={featuredApps} />
      </section>

      <div className="grid md:grid-cols-2 gap-8">
        <section className="bg-card/50 p-8 rounded-[2.5rem] border shadow-lg space-y-6 hover:shadow-primary/5 transition-all duration-500 group">
          <div className="flex items-center gap-4">
             <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Zap className="w-8 h-8 text-primary" />
             </div>
             <div>
               <h3 className="text-2xl font-black tracking-tight">Mod APKs</h3>
               <p className="text-muted-foreground text-sm font-medium italic">Premium Unlocked</p>
             </div>
          </div>
          <p className="text-muted-foreground leading-relaxed text-sm">
            Access thousands of premium applications and modded games with all features unlocked for free. Safe, fast, and constantly updated.
          </p>
          <Button asChild className="w-full rounded-xl h-14 font-black text-lg group click-effect">
            <Link to="/mod-apks">
              Browse Mods <ChevronRight className="w-5 h-5 ml-2 transition-transform group-hover:translate-x-1" />
            </Link>
          </Button>
        </section>

        <section className="bg-card/50 p-8 rounded-[2.5rem] border shadow-lg space-y-6 hover:shadow-accent/5 transition-all duration-500 group">
          <div className="flex items-center gap-4">
             <div className="w-16 h-16 rounded-2xl bg-accent/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Download className="w-8 h-8 text-accent" />
             </div>
             <div>
               <h3 className="text-2xl font-black tracking-tight">TikTok⬆️</h3>
               <p className="text-muted-foreground text-sm font-medium italic">No Watermark</p>
             </div>
          </div>
          <p className="text-muted-foreground leading-relaxed text-sm">
            The ultimate tool for TikTok users. Download any video in HD quality without watermark instantly. High speed and high quality results.
          </p>
          <Button variant="outline" asChild className="w-full rounded-xl h-14 font-black text-lg border-2 group click-effect">
            <Link to="/tiktok">
              Try Downloader <ChevronRight className="w-5 h-5 ml-2 transition-transform group-hover:translate-x-1" />
            </Link>
          </Button>
        </section>
      </div>

      <section>
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
             <Info className="w-6 h-6 text-primary" />
             <h2 className="text-2xl font-black uppercase italic tracking-tighter">New Arrivals</h2>
          </div>
          <Button variant="ghost" asChild className="group click-effect">
            <Link to="/mod-apks" className="flex items-center gap-2 font-bold">
              View All <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </Button>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
          {mockApps.slice(0, 6).map((app) => (
            <AppCard key={app.id} app={app} />
          ))}
        </div>
      </section>
    </div>
  );
};
