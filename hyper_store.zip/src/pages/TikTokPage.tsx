import React, { useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Download, Loader2, Copy, CheckCircle2, Video, Music, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/db/supabase';

interface VideoData {
  id: string;
  title: string;
  videoUrl: string;
  hdVideoUrl: string;
  audioUrl: string;
  coverImage: string;
  duration: number;
  author: {
    unique_id: string;
    nickname: string;
    avatar: string;
  };
}

export const TikTokPage: React.FC = () => {
  const { t } = useLanguage();
  const [url, setUrl] = useState('');
  const [format, setFormat] = useState<'mp4' | 'mp3'>('mp4');
  const [quality, setQuality] = useState<'sd' | 'hd'>('hd');
  const [isLoading, setIsLoading] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [videoData, setVideoData] = useState<VideoData | null>(null);

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setUrl(text);
      toast.success('Link pasted!');
    } catch (error) {
      toast.error('Failed to paste. Please paste manually.');
    }
  };

  const handleDownload = async () => {
    if (!url.trim()) {
      toast.error('Please enter a TikTok video URL');
      return;
    }

    if (!url.includes('tiktok.com')) {
      toast.error('Please enter a valid TikTok URL');
      return;
    }

    setIsLoading(true);
    setVideoData(null);

    try {
      const { data, error } = await supabase.functions.invoke('tiktok-download', {
        body: { url, hd: quality === 'hd' }
      });

      if (error) {
        const errorMsg = await error?.context?.text();
        throw new Error(errorMsg || error.message);
      }

      if (data?.error) {
        throw new Error(data.error);
      }

      if (data?.success && data?.data) {
        setVideoData(data.data);
        toast.success('Video ready for download!');
      } else {
        throw new Error('Invalid response from server');
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to process video. Please try again.');
      console.error('Download error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDirectDownload = async (downloadUrl: string, filename: string) => {
    try {
      setIsDownloading(true);
      setDownloadProgress(0);
      
      // Simulate progress for 5 seconds
      const progressInterval = setInterval(() => {
        setDownloadProgress((prev) => {
          if (prev >= 90) return prev;
          return prev + 10;
        });
      }, 500);
      
      toast.info('Preparing download...');
      
      // Use our download proxy Edge Function to force download
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      const response = await fetch(
        `${supabaseUrl}/functions/v1/download-proxy`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${supabaseKey}`,
          },
          body: JSON.stringify({ url: downloadUrl, filename })
        }
      );

      if (!response.ok) {
        throw new Error('Download failed');
      }

      const blob = await response.blob();
      setDownloadProgress(100);
      clearInterval(progressInterval);
      
      const blobUrl = window.URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename;
      link.style.display = 'none';
      
      document.body.appendChild(link);
      link.click();
      
      setTimeout(() => {
        document.body.removeChild(link);
        window.URL.revokeObjectURL(blobUrl);
        setIsDownloading(false);
        setDownloadProgress(0);
      }, 100);
      
      toast.success('Download started!');
    } catch (error) {
      console.error('Download error:', error);
      setIsDownloading(false);
      setDownloadProgress(0);
      toast.error('Download failed. Opening video in new tab...');
      // Fallback: open in new tab
      window.open(downloadUrl, '_blank');
    }
  };

  const getDownloadUrl = () => {
    if (!videoData) return '';
    if (format === 'mp3') return videoData.audioUrl;
    return quality === 'hd' ? videoData.hdVideoUrl : videoData.videoUrl;
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-fade-in pb-10">
      {/* Header with gradient background */}
      <div className="relative overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-purple-600 via-pink-500 to-blue-500 p-8 md:p-14 text-center shadow-2xl group">
        <div className="absolute inset-0 bg-black/10" />
        <div className="relative z-10 flex flex-col items-center gap-6">
          <div className="w-24 h-24 md:w-32 md:h-32 rounded-[2rem] bg-white/20 backdrop-blur-md p-4 shadow-2xl group-hover:rotate-6 transition-transform duration-500">
             <img 
               src="https://miaoda-conversation-file.s3cdn.medo.dev/user-a7ntqp350veo/conv-aefi7t2hyw3k/20260414/file-axxds4b3lc74.png" 
               alt="TikTok Downloader Logo" 
               className="w-full h-full object-contain"
             />
          </div>
          <div className="space-y-4">
            <h1 className="text-4xl md:text-7xl font-black text-white drop-shadow-2xl italic tracking-tighter">
              TikTok Downloader
            </h1>
            <p className="text-lg md:text-2xl text-white/90 font-bold drop-shadow-lg">
              Download videos without watermark - Fast & Free
            </p>
          </div>
        </div>
      </div>

      {/* Main download card */}
      <Card className="border-none shadow-2xl rounded-3xl overflow-hidden bg-card/95 backdrop-blur-md">
        <CardContent className="p-6 md:p-8 space-y-6">
          {/* URL Input with Paste button */}
          <div className="relative">
            <Input
              type="url"
              placeholder="Insert a link here"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="h-14 pr-24 text-base rounded-2xl border-2 focus:border-primary"
              disabled={isLoading}
            />
            <Button
              onClick={handlePaste}
              variant="ghost"
              className="absolute right-2 top-1/2 -translate-y-1/2 text-primary font-bold hover:bg-primary/10 click-effect"
              disabled={isLoading}
            >
              <Copy className="w-4 h-4 mr-2" />
              Paste
            </Button>
          </div>

          {/* Format and Quality Selection */}
          <div className="grid grid-cols-2 gap-4">
            {/* Format Selection */}
            <div className="space-y-2">
              <label className="text-sm font-bold text-muted-foreground">Format</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setFormat('mp4')}
                    disabled={isLoading}
                    className={`p-3 rounded-xl border-2 transition-all click-effect ${
                      format === 'mp4'
                        ? 'border-primary bg-primary/10 text-primary'
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    <Video className="w-5 h-5 mx-auto mb-1" />
                    <span className="text-xs font-bold">MP4</span>
                  </button>
                  <button
                    onClick={() => setFormat('mp3')}
                    disabled={isLoading}
                    className={`p-3 rounded-xl border-2 transition-all click-effect ${
                      format === 'mp3'
                        ? 'border-primary bg-primary/10 text-primary'
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    <Music className="w-5 h-5 mx-auto mb-1" />
                    <span className="text-xs font-bold">MP3</span>
                  </button>
                </div>
              </div>

              {/* Quality Selection (only for MP4) */}
              {format === 'mp4' && (
                <div className="space-y-2">
                  <label className="text-sm font-bold text-muted-foreground">Quality</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setQuality('sd')}
                      disabled={isLoading}
                      className={`p-3 rounded-xl border-2 transition-all click-effect ${
                        quality === 'sd'
                          ? 'border-primary bg-primary/10 text-primary'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <span className="text-xs font-bold">SD</span>
                    </button>
                    <button
                      onClick={() => setQuality('hd')}
                      disabled={isLoading}
                      className={`p-3 rounded-xl border-2 transition-all click-effect ${
                        quality === 'hd'
                          ? 'border-primary bg-primary/10 text-primary'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <span className="text-xs font-bold">HD</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Download Button */}
            <Button
              onClick={handleDownload}
              disabled={isLoading || !url.trim()}
              className="w-full h-14 text-lg font-bold rounded-2xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 click-effect shadow-lg"
              size="lg"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Download className="w-5 h-5 mr-2" />
                  Download
                </>
              )}
            </Button>

            {/* Video Preview and Download */}
            {videoData && (
              <div className="space-y-4 p-6 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30 border-2 border-green-500/50 rounded-2xl animate-scale-in">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-8 h-8 text-green-600 dark:text-green-400 shrink-0" />
                  <div className="flex-1">
                    <h3 className="font-bold text-lg text-green-900 dark:text-green-100">Ready to Download!</h3>
                    <p className="text-sm text-green-700 dark:text-green-300">{videoData.title}</p>
                  </div>
                </div>

                {/* Author Info */}
                <div className="flex items-center gap-3 p-3 bg-white/50 dark:bg-black/20 rounded-xl">
                  <img 
                    src={videoData.author.avatar} 
                    alt={videoData.author.nickname}
                    className="w-10 h-10 rounded-full"
                  />
                  <div>
                    <p className="font-bold text-sm">{videoData.author.nickname}</p>
                    <p className="text-xs text-muted-foreground">@{videoData.author.unique_id}</p>
                  </div>
                </div>

                {/* Download Button */}
                <Button
                  onClick={() => handleDirectDownload(
                    getDownloadUrl(),
                    `tiktok_${videoData.id}.${format === 'mp3' ? 'mp3' : 'mp4'}`
                  )}
                  disabled={isDownloading}
                  className="w-full h-12 bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-800 click-effect font-bold disabled:opacity-70 disabled:cursor-not-allowed"
                >
                  {isDownloading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Download starting... {downloadProgress}%
                    </>
                  ) : (
                    <>
                      <Download className="w-5 h-5 mr-2" />
                      Download {format.toUpperCase()} {format === 'mp4' && `(${quality.toUpperCase()})`}
                    </>
                  )}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Features Section */}
        <div className="grid md:grid-cols-3 gap-4">
          <Card className="border-none shadow-lg rounded-2xl bg-card/80 backdrop-blur-sm">
            <CardContent className="p-6 text-center space-y-3">
              <div className="w-12 h-12 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-black text-lg">Unlimited</h3>
              <p className="text-sm text-muted-foreground">
                Save TikTok videos as much as you need - without any limits.
              </p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg rounded-2xl bg-card/80 backdrop-blur-sm">
            <CardContent className="p-6 text-center space-y-3">
              <div className="w-12 h-12 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-black text-lg">No Watermark!</h3>
              <p className="text-sm text-muted-foreground">
                Download TikTok video in MP4 or remove a TT logo.
              </p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg rounded-2xl bg-card/80 backdrop-blur-sm">
            <CardContent className="p-6 text-center space-y-3">
              <div className="w-12 h-12 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
                <Video className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-black text-lg">MP4 and MP3</h3>
              <p className="text-sm text-muted-foreground">
                Save files in HD quality, convert TikTok to MP4 or MP3.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Footer text */}
        <div className="text-center">
          <h2 className="text-2xl md:text-3xl font-black mb-2">Download TikTok videos online</h2>
          <p className="text-muted-foreground">Fast, free, and no watermark</p>
        </div>
      </div>
  );
};
