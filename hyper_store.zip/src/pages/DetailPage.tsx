import React from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { mockApps } from '@/data/mockData';
import { Button } from '@/components/ui/button';
import { ChevronLeft, Download, Star, Share2, MoreVertical, Shield, Info } from 'lucide-react';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';

export const DetailPage: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const app = mockApps.find((a) => a.id === id);

  if (!app) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] space-y-4">
        <h2 className="text-2xl font-bold">App Not Found</h2>
        <Button asChild>
          <Link to="/">Go Home</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto animate-fade-in pb-8">
      {/* Header with Back Button */}
      <div className="flex items-center gap-4 mb-6 sticky top-0 bg-background/80 backdrop-blur-xl z-10 py-4 -mx-4 px-4 border-b">
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full"
          onClick={() => navigate(-1)}
        >
          <ChevronLeft className="w-6 h-6" />
        </Button>
        <h1 className="text-xl font-black truncate flex-1">{app.name}</h1>
        <Button variant="ghost" size="icon" className="rounded-full" onClick={() => {}}>
          <Share2 className="w-5 h-5" />
        </Button>
        <Button variant="ghost" size="icon" className="rounded-full" onClick={() => {}}>
          <MoreVertical className="w-5 h-5" />
        </Button>
      </div>

      {/* App Header Section */}
      <div className="flex gap-6 mb-8">
        <div className={`w-32 h-32 rounded-3xl shadow-2xl overflow-hidden shrink-0 flex items-center justify-center text-white font-black text-5xl border-2 border-border ${app.color || 'bg-muted'}`}>
          {app.icon ? (
            <img src={app.icon} alt={app.name} className="w-full h-full object-cover" />
          ) : (
            <span className="opacity-40">{app.name[0]}</span>
          )}
        </div>
        <div className="flex-1 space-y-3">
          <div>
            <h2 className="text-3xl font-black mb-1">{app.name}</h2>
            <p className="text-primary font-bold">{app.category === 'game' ? 'Game' : 'App'}</p>
          </div>
          <p className="text-muted-foreground text-sm line-clamp-2">{app.tagline}</p>
        </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="text-center">
          <div className="flex items-center justify-center gap-1 mb-1">
            <span className="text-2xl font-black">4.8</span>
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
          </div>
          <div className="text-xs text-muted-foreground">★★★★★</div>
        </div>
        <div className="text-center border-x">
          <div className="text-2xl font-black mb-1">50K+</div>
          <div className="text-xs text-muted-foreground font-bold">Downloads</div>
        </div>
        <div className="text-center">
          <div className="flex items-center justify-center gap-1 mb-1">
            <Shield className="w-5 h-5 text-primary" />
          </div>
          <div className="text-xs text-muted-foreground font-bold">Rated for 3+</div>
        </div>
      </div>

      {/* Download Button */}
      {app.downloadUrl.startsWith('/') ? (
        <Button 
          size="lg" 
          className="w-full rounded-2xl py-8 text-xl font-black shadow-xl shadow-primary/20 mb-8"
          asChild
        >
          <Link to={app.downloadUrl}>
            <Download className="mr-3 w-6 h-6" />
            Go to Tool
          </Link>
        </Button>
      ) : (
        <Button 
          size="lg" 
          className="w-full rounded-2xl py-8 text-xl font-black shadow-xl shadow-primary/20 mb-8"
          asChild
        >
          <a href={app.downloadUrl}>
            <Download className="mr-3 w-6 h-6" />
            Install
          </a>
        </Button>
      )}

      <Separator className="my-8" />

      {/* App Info Grid - Moved up as requested */}
      <section className="mb-8">
        <h3 className="text-lg font-black mb-4">App info</h3>
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Version</span>
            <span className="text-sm font-bold">{app.version || '1.0.0'}</span>
          </div>
          <Separator />
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Updated on</span>
            <span className="text-sm font-bold">{app.updatedAt || 'Mar 20, 2026'}</span>
          </div>
          <Separator />
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Size</span>
            <span className="text-sm font-bold">{app.size || '25 MB'}</span>
          </div>
          <Separator />
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Category</span>
            <span className="text-sm font-bold capitalize">{app.category}</span>
          </div>
        </div>
      </section>

      <Separator className="my-8" />

      {/* About Section - Moved to bottom as requested */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-black">About this {app.category}</h3>
          <Button variant="ghost" size="sm" className="text-primary font-bold" onClick={() => {}}>
            <Info className="w-4 h-4 mr-2" />
            More
          </Button>
        </div>
        <p className="text-muted-foreground leading-relaxed mb-4">
          {app.description}
        </p>
        <p className="text-muted-foreground leading-relaxed text-sm">
          This is a placeholder description block for visually complete UI. In a real application, this would contain more detailed information about the app's features and update history.
        </p>
      </section>
    </div>
  );
};
