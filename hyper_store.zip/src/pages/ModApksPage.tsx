import React, { useState } from 'react';
import { games, apps } from '@/data/mockData';
import { AppCard } from '@/components/store/AppCard';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Gamepad2, LayoutGrid } from 'lucide-react';

export const ModApksPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('games');

  return (
    <div className="space-y-10 animate-fade-in max-w-7xl mx-auto py-6">
      <header className="space-y-4">
        <h1 className="text-5xl md:text-7xl font-black tracking-tighter italic bg-gradient-to-r from-primary via-primary/80 to-accent bg-clip-text text-transparent">
          MOD APKs
        </h1>
        <p className="text-muted-foreground text-xl md:text-2xl font-medium max-w-2xl">
          Premium tools and modded games for free. Exclusive access to the best premium content.
        </p>
      </header>

      <Tabs defaultValue="games" className="w-full" onValueChange={setActiveTab}>
        <div className="flex items-center justify-between mb-8 overflow-x-auto pb-2">
          <TabsList className="bg-card border h-auto p-1.5 rounded-2xl">
            <TabsTrigger 
              value="games" 
              className="px-8 py-3 rounded-xl data-[state=active]:bg-primary data-[state=active]:text-primary-foreground flex items-center gap-2 text-lg font-bold transition-all duration-300"
            >
              <Gamepad2 className="w-5 h-5" />
              Games
            </TabsTrigger>
            <TabsTrigger 
              value="apps" 
              className="px-8 py-3 rounded-xl data-[state=active]:bg-accent data-[state=active]:text-accent-foreground flex items-center gap-2 text-lg font-bold transition-all duration-300"
            >
              <LayoutGrid className="w-5 h-5" />
              Apps
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="games" className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6 md:gap-8">
            {games.map((game) => (
              <AppCard key={game.id} app={game} />
            ))}
          </div>
          {games.length === 0 && (
            <div className="text-center py-20 bg-card/50 rounded-3xl border border-dashed">
              <p className="text-muted-foreground text-xl">No modded games available yet.</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="apps" className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6 md:gap-8">
            {apps.map((app) => (
              <AppCard key={app.id} app={app} />
            ))}
          </div>
          {apps.length === 0 && (
            <div className="text-center py-20 bg-card/50 rounded-3xl border border-dashed">
              <p className="text-muted-foreground text-xl">No modded apps available yet.</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};
