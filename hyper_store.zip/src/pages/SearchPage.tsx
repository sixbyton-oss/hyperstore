import React, { useState, useMemo } from 'react';
import { mockApps } from '@/data/mockData';
import { AppCard } from '@/components/store/AppCard';
import { Input } from '@/components/ui/input';
import { Search as SearchIcon, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

export const SearchPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredApps = useMemo(() => {
    if (!searchTerm.trim()) return [];
    const term = searchTerm.toLowerCase();
    return mockApps.filter(
      (app) =>
        app.name.toLowerCase().includes(term) ||
        app.tagline.toLowerCase().includes(term) ||
        app.description.toLowerCase().includes(term)
    );
  }, [searchTerm]);

  return (
    <div className="space-y-12 animate-fade-in max-w-7xl mx-auto">
      <header className="flex flex-col items-center gap-8 mb-16">
        <h1 className="text-5xl font-black text-center">Find what you love</h1>
        <div className="relative w-full max-w-3xl group shadow-2xl rounded-full">
          <SearchIcon className="absolute left-6 top-1/2 -translate-y-1/2 w-6 h-6 text-muted-foreground group-focus-within:text-primary transition-colors" />
          <Input
            placeholder="Search for apps, games and more..."
            className="pl-16 pr-12 h-16 md:h-20 text-xl rounded-full border-2 focus-visible:ring-primary/20 focus-visible:border-primary transition-all bg-card/50 backdrop-blur-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          {searchTerm && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-6 top-1/2 -translate-y-1/2 hover:bg-transparent"
              onClick={() => setSearchTerm('')}
            >
              <X className="w-6 h-6 text-muted-foreground hover:text-foreground" />
            </Button>
          )}
        </div>
      </header>

      <section>
        {searchTerm.trim() ? (
          filteredApps.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-7 gap-x-6 gap-y-10">
              {filteredApps.map((app) => (
                <AppCard key={app.id} app={app} />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-20 text-center space-y-6">
              <div className="w-32 h-32 rounded-full bg-muted flex items-center justify-center">
                 <SearchIcon className="w-12 h-12 text-muted-foreground/50" />
              </div>
              <div className="space-y-2">
                <h3 className="text-3xl font-bold">No results found</h3>
                <p className="text-xl text-muted-foreground max-w-md mx-auto">We couldn't find anything matching "{searchTerm}". Try different keywords or check your spelling.</p>
              </div>
            </div>
          )
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 opacity-60">
             <div className="p-8 border-2 border-dashed rounded-3xl flex flex-col items-center justify-center text-center space-y-4">
                <SearchIcon className="w-12 h-12" />
                <p className="font-bold text-lg">Type to start searching</p>
             </div>
             {/* Trending placeholders */}
             <div className="col-span-1 md:col-span-2 space-y-4">
                <h3 className="font-bold text-xl px-2">Recent Searches</h3>
                <div className="flex flex-wrap gap-2">
                   {['Action Games', 'Productivity', 'Social', 'Photo Editor', 'Racing'].map(tag => (
                      <Button key={tag} variant="secondary" className="rounded-full px-6" onClick={() => setSearchTerm(tag)}>{tag}</Button>
                   ))}
                </div>
             </div>
          </div>
        )}
      </section>
    </div>
  );
};
