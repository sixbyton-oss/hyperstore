import React, { useState } from 'react';
import { useTheme, Theme } from '@/contexts/ThemeContext';
import { useLanguage, Language } from '@/contexts/LanguageContext';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Bell, Globe, Shield, User, ChevronRight, Palette, Check, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { LoadingTransition } from '@/components/LoadingTransition';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

export const SettingsPage: React.FC = () => {
  const { theme, setTheme, isChangingTheme } = useTheme();
  const { language, setLanguage, t } = useLanguage();
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [languageDialogOpen, setLanguageDialogOpen] = useState(false);

  const themes: { value: Theme; label: string; color: string; icon?: string }[] = [
    { value: 'light', label: t('light'), color: 'bg-white border-2 border-gray-300' },
    { value: 'dark', label: t('dark'), color: 'bg-gray-900' },
    { value: 'neon', label: t('neon'), color: 'bg-gradient-to-r from-purple-600 via-pink-600 to-cyan-500' },
    { value: 'pink', label: t('pink'), color: 'bg-gradient-to-r from-pink-400 to-pink-600' },
    { value: 'green', label: t('green'), color: 'bg-gradient-to-r from-green-400 to-emerald-600' },
    { value: 'blue', label: t('blue'), color: 'bg-gradient-to-r from-blue-400 to-blue-600' },
    { value: 'christmas', label: '🎄 Christmas', color: 'bg-gradient-to-r from-red-500 to-green-600', icon: '🎄' },
    { value: 'newyear', label: '🎆 New Year', color: 'bg-gradient-to-r from-yellow-400 via-purple-500 to-pink-500', icon: '🎆' },
    { value: 'summer', label: '☀️ Summer', color: 'bg-gradient-to-r from-yellow-300 via-orange-400 to-cyan-400', icon: '☀️' }
  ];

  const languages: { value: Language; label: string; flag: string }[] = [
    { value: 'en', label: 'English', flag: '🇺🇸' },
    { value: 'es', label: 'Español', flag: '🇪🇸' },
    { value: 'fr', label: 'Français', flag: '🇫🇷' },
    { value: 'zh', label: '简体中文', flag: '🇨🇳' },
    { value: 'de', label: 'Deutsch', flag: '🇩🇪' },
    { value: 'ja', label: '日本語', flag: '🇯🇵' },
    { value: 'pt', label: 'Português', flag: '🇵🇹' },
    { value: 'ar', label: 'العربية', flag: '🇸🇦' },
    { value: 'hi', label: 'हिंदी', flag: '🇮🇳' }
  ];

  const handleNotificationToggle = (checked: boolean) => {
    setNotificationsEnabled(checked);
    if (checked) {
      toast.success(t('notificationsEnabled'));
    } else {
      toast.info(t('notificationsDisabled'));
    }
  };

  const handleLanguageSelect = (lang: Language) => {
    setLanguage(lang);
    setLanguageDialogOpen(false);
    toast.success(`Language changed to ${languages.find(l => l.value === lang)?.label}`);
  };

  const settingsGroups = [
    {
      title: t('appearance'),
      items: [
        {
          id: 'theme',
          label: t('theme'),
          description: t('themeDescription'),
          icon: Palette,
          action: (
            <div className="grid grid-cols-3 gap-3">
              {themes.map((thm) => (
                <button
                  key={thm.value}
                  onClick={() => setTheme(thm.value)}
                  className={`flex flex-col items-center gap-2 p-3 rounded-xl transition-all click-effect ${
                    theme === thm.value ? 'ring-2 ring-primary bg-primary/5' : 'hover:bg-muted/50'
                  }`}
                >
                  <div className={`w-14 h-14 rounded-full ${thm.color} shadow-lg flex items-center justify-center text-2xl`}>
                    {thm.icon || ''}
                  </div>
                  <span className="text-xs font-bold text-center">{thm.label}</span>
                </button>
              ))}
            </div>
          )
        }
      ]
    },
    {
      title: t('preferences'),
      items: [
        {
          id: 'notifications',
          label: t('pushNotifications'),
          description: t('notificationsDescription'),
          icon: Bell,
          action: (
            <Switch 
              checked={notificationsEnabled} 
              onCheckedChange={handleNotificationToggle}
            />
          )
        }
      ]
    },
    {
      title: t('accountSecurity'),
      items: [
        {
          id: 'profile',
          label: t('profileSettings'),
          description: t('profileDescription'),
          icon: User,
          action: (
            <Button variant="ghost" size="sm" asChild className="p-0 hover:bg-transparent click-effect">
              <Link to="/profile">
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </Link>
            </Button>
          )
        },
        {
          id: 'language',
          label: t('language'),
          description: languages.find(l => l.value === language)?.label || 'English',
          icon: Globe,
          action: (
            <Dialog open={languageDialogOpen} onOpenChange={setLanguageDialogOpen}>
              <DialogTrigger asChild>
                <button 
                  className="text-xs font-bold text-primary hover:text-primary/80 transition-colors click-effect"
                >
                  {t('change')}
                </button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>{t('language')}</DialogTitle>
                  <DialogDescription>
                    Select your preferred language
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-2 py-4">
                  {languages.map((lang) => (
                    <button
                      key={lang.value}
                      onClick={() => handleLanguageSelect(lang.value)}
                      className={`w-full flex items-center justify-between p-4 rounded-lg transition-all click-effect ${
                        language === lang.value 
                          ? 'bg-primary/10 ring-2 ring-primary' 
                          : 'hover:bg-muted/50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-3xl">{lang.flag}</span>
                        <span className="font-bold">{lang.label}</span>
                      </div>
                      {language === lang.value && (
                        <Check className="w-5 h-5 text-primary" />
                      )}
                    </button>
                  ))}
                </div>
              </DialogContent>
            </Dialog>
          )
        }
      ]
    },
    {
      title: 'Data & Backup',
      items: [
        {
          id: 'download-source',
          label: 'Download Source Code',
          description: 'Download the complete source code to rebuild and deploy anywhere. Requires Node.js to build.',
          icon: Download,
          action: (
            <Button 
              variant="outline" 
              onClick={() => {
                const link = document.createElement('a');
                link.href = '/hyper-store-backup.zip';
                link.download = 'hyper-store-backup.zip';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                toast.success('Source code download started!');
              }} 
              className="click-effect font-bold rounded-xl"
            >
               Source ZIP
            </Button>
          )
        },
        {
          id: 'download-instructions',
          label: 'Build Instructions',
          description: 'To deploy: Extract ZIP → Run "npm install" → Run "npm run build" → Deploy the /dist folder.',
          icon: Shield,
          action: (
            <Button 
              variant="ghost" 
              onClick={() => {
                toast.info('Extract the source ZIP, install dependencies with npm install, then build with npm run build. The /dist folder will contain deployable files.');
              }} 
              className="click-effect font-bold rounded-xl text-xs"
            >
               View Guide
            </Button>
          )
        }
      ]
    }
  ];

  return (
    <>
      {isChangingTheme && <LoadingTransition message="Applying theme..." />}
      <div className="max-w-3xl mx-auto space-y-12 animate-fade-in pb-10">
        <header className="space-y-4">
          <h1 className="text-4xl font-black tracking-tight">{t('settingsTitle')}</h1>
          <p className="text-xl text-muted-foreground">{t('settingsSubtitle')}</p>
        </header>

        <div className="space-y-8">
          {settingsGroups.map((group) => (
            <section key={group.title} className="space-y-4">
              <h3 className="text-xs font-black uppercase tracking-[0.2em] text-muted-foreground/80 px-4">{group.title}</h3>
              <Card className="border-none shadow-xl rounded-3xl overflow-hidden bg-card/80 backdrop-blur-md">
                <CardContent className="p-0">
                  <div className="divide-y">
                    {group.items.map((item) => (
                      <div key={item.id} className="flex items-start justify-between p-6 hover:bg-muted/30 transition-colors">
                        <div className="flex items-start gap-5 flex-1">
                          <div className="w-12 h-12 rounded-2xl bg-muted flex items-center justify-center shrink-0">
                             <item.icon className="w-6 h-6 text-primary" />
                          </div>
                          <div className="space-y-3 flex-1">
                            <div className="space-y-1">
                              <Label htmlFor={item.id} className="text-lg font-bold cursor-pointer">{item.label}</Label>
                              <p className="text-sm text-muted-foreground">{item.description}</p>
                            </div>
                            {item.id === 'theme' && (
                              <div className="pt-2">
                                {item.action}
                              </div>
                            )}
                          </div>
                        </div>
                        {item.id !== 'theme' && (
                          <div className="pl-4">
                            {item.action}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </section>
          ))}

          <section className="space-y-4 pt-4">
            <Card className="border-2 border-dashed rounded-3xl p-8 flex flex-col items-center justify-center text-center space-y-4 bg-transparent">
              <Shield className="w-10 h-10 text-muted-foreground/50" />
              <div className="space-y-1">
                 <h3 className="font-bold text-lg">Hyper Store v1.0.0</h3>
                 <p className="text-sm text-muted-foreground">{t('dataStored')}</p>
              </div>
              <p className="text-xs font-medium text-muted-foreground">{t('copyright')}</p>
            </Card>
          </section>
        </div>
      </div>
    </>
  );
};
