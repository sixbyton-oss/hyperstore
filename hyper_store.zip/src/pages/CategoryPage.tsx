import React from 'react';
import { useLocation } from 'react-router-dom';
import { games, apps } from '@/data/mockData';
import { AppListItem } from '@/components/store/AppListItem';

export const CategoryPage: React.FC = () => {
  const location = useLocation();
  const isGames = location.pathname.includes('/games');
  const items = isGames ? games : apps;
  const title = isGames ? 'Games' : 'Apps';

  return (
    <div className="space-y-8 animate-fade-in max-w-5xl mx-auto">
      <header className="mb-10 space-y-3">
        <h1 className="text-5xl font-black tracking-tight">{title}</h1>
        <p className="text-muted-foreground text-lg">
          Discover the best {title.toLowerCase()} for your device. Browse our curated collection.
        </p>
      </header>

      <div className="space-y-3">
        {items.map((item, index) => (
          <AppListItem key={item.id} app={item} rank={index + 1} />
        ))}
      </div>
    </div>
  );
};
