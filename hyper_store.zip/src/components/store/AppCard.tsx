import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { AppInfo } from '@/types/store';
import { Link } from 'react-router-dom';

interface AppCardProps {
  app: AppInfo;
}

export const AppCard: React.FC<AppCardProps> = ({ app }) => {
  return (
    <Link to={`/app/${app.id}`} className="click-effect">
      <Card className="overflow-hidden card-hover border-none bg-transparent shadow-none group">
        <CardContent className="p-0">
          <div className={`aspect-square rounded-2xl overflow-hidden mb-3 flex items-center justify-center text-white font-bold text-2xl shadow-inner ${app.color || 'bg-muted'}`}>
            {app.icon ? (
              <img
                src={app.icon}
                alt={app.name}
                className="w-full h-full object-cover transition-transform group-hover:scale-105"
              />
            ) : (
              <span className="opacity-40 group-hover:scale-110 transition-transform">{app.name[0]}</span>
            )}
          </div>
          <div className="px-1">
            <h3 className="font-semibold text-sm md:text-md truncate">{app.name}</h3>
            <p className="text-xs text-muted-foreground truncate">{app.tagline}</p>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
};
