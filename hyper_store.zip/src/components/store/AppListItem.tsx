import React from 'react';
import { Card } from '@/components/ui/card';
import { AppInfo } from '@/types/store';
import { Link } from 'react-router-dom';
import { Star, Download } from 'lucide-react';

interface AppListItemProps {
  app: AppInfo;
  rank?: number;
}

export const AppListItem: React.FC<AppListItemProps> = ({ app, rank }) => {
  return (
    <Link to={`/app/${app.id}`}>
      <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 border-none bg-card/50 backdrop-blur-sm group">
        <div className="flex items-center gap-4 p-4">
          {/* Rank Number */}
          {rank && (
            <div className="text-2xl font-black text-muted-foreground/30 w-8 text-center shrink-0">
              {rank}
            </div>
          )}

          {/* App Icon */}
          <div className={`w-16 h-16 rounded-2xl overflow-hidden shrink-0 flex items-center justify-center text-white font-black text-xl shadow-lg group-hover:scale-110 transition-transform ${app.color || 'bg-muted'}`}>
            {app.icon ? (
              <img
                src={app.icon}
                alt={app.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <span className="opacity-40">{app.name[0]}</span>
            )}
          </div>

          {/* App Info */}
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-md truncate group-hover:text-primary transition-colors">
              {app.name}
            </h3>
            <p className="text-sm text-muted-foreground truncate">
              {app.tagline}
            </p>
            <div className="flex items-center gap-4 mt-1">
              <div className="flex items-center gap-1 text-xs">
                <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                <span className="font-bold">4.8</span>
              </div>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Download className="w-3 h-3" />
                <span>10K+</span>
              </div>
            </div>
          </div>

          {/* Category Badge */}
          <div className="hidden md:block">
            <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
              app.category === 'game' 
                ? 'bg-primary/10 text-primary' 
                : 'bg-accent/10 text-accent'
            }`}>
              {app.category}
            </span>
          </div>
        </div>
      </Card>
    </Link>
  );
};
