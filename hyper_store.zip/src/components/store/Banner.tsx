import React, { useEffect, useState } from 'react';
import { AppInfo } from '@/types/store';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious, type CarouselApi } from '@/components/ui/carousel';

interface BannerProps {
  apps: AppInfo[];
}

export const Banner: React.FC<BannerProps> = ({ apps }) => {
  const [api, setApi] = useState<CarouselApi>();
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    if (!api) return;
    
    setCurrent(api.selectedScrollSnap());
    api.on("select", () => {
      setCurrent(api.selectedScrollSnap());
    });
  }, [api]);

  return (
    <div className="relative group/banner w-full">
      <Carousel setApi={setApi} className="w-full mb-8" opts={{ loop: true }}>
        <CarouselContent className="-ml-4">
          {apps.map((app, index) => (
            <CarouselItem key={app.id} className="pl-4">
              <div className="relative h-[450px] md:h-[550px] w-full rounded-[2.5rem] md:rounded-[3.5rem] overflow-hidden bg-card border-2 border-border/50 shadow-2xl">
                {/* Visual Depth Background */}
                <div className={`absolute inset-0 ${app.color || 'bg-muted'} opacity-[0.05]`} />
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.1),transparent)]" />
                
                {/* Content Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t md:bg-gradient-to-r from-black/90 via-black/40 to-transparent flex items-end md:items-center p-8 md:p-20 text-white group">
                  <div className="w-full max-w-3xl space-y-6 md:space-y-10 animate-in fade-in slide-in-from-left-8 duration-700">
                    <div className="flex items-center gap-4">
                      <span className="px-5 py-2 bg-primary rounded-full text-[12px] font-black uppercase tracking-[0.2em] shadow-2xl shadow-primary/50 animate-pulse">
                        Spotlight
                      </span>
                      <span className="text-sm font-black text-white/40 uppercase tracking-[0.3em]">
                        {app.category === 'tool' ? 'New Feature' : `Top ${index + 1} Choice`}
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-6 md:gap-10">
                      <div className={`w-28 h-28 md:w-44 md:h-44 rounded-[2.5rem] flex items-center justify-center text-white font-black text-5xl md:text-7xl shadow-[0_40px_80px_rgba(0,0,0,0.7)] border-4 border-white/10 relative overflow-hidden group-hover:rotate-6 transition-transform duration-700 shrink-0 ${app.color || 'bg-white/20'}`}>
                         <div className="absolute inset-0 bg-gradient-to-br from-white/40 to-transparent pointer-events-none" />
                         {app.icon ? (
                           <img src={app.icon} alt={app.name} className="w-full h-full object-cover" />
                         ) : (
                           <span className="drop-shadow-2xl">{app.name[0]}</span>
                         )}
                      </div>
                      <div className="space-y-2 md:space-y-4">
                         <h2 className="text-5xl md:text-8xl font-black tracking-tighter drop-shadow-2xl leading-none">{app.name}</h2>
                         <p className="text-2xl md:text-4xl text-primary font-black italic drop-shadow-xl tracking-tight">{app.tagline}</p>
                      </div>
                    </div>

                    <p className="hidden md:block text-white/60 text-2xl leading-relaxed line-clamp-2 max-w-2xl font-medium border-l-4 border-primary/40 pl-8">
                      {app.description}
                    </p>

                    <div className="flex flex-wrap items-center gap-8">
                      <Button asChild className="rounded-[2rem] px-14 py-10 text-3xl font-black shadow-2xl shadow-primary/40 hover:scale-110 active:scale-95 transition-all bg-primary hover:bg-white hover:text-primary border-none">
                        <Link to={`/app/${app.id}`}>Explore Now</Link>
                      </Button>
                      
                      <div className="hidden lg:flex items-center gap-6 text-white/20 text-[12px] font-black uppercase tracking-[0.5em] px-8 py-4 rounded-full border border-white/5 glass-effect">
                        <span>Slide</span>
                        <div className="w-16 h-[3px] bg-white/5 relative overflow-hidden rounded-full">
                          <div className="absolute inset-0 bg-primary/40 animate-slide-in" />
                        </div>
                        <span>More</span>
                      </div>
                    </div>
                  </div>
                  {/* Mobile Slide Indicator */}

                </div>
              </div>
            </CarouselItem>
          ))}
        </CarouselContent>
        
        {/* Navigation Buttons (Desktop) */}
        <div className="hidden lg:block">
          <CarouselPrevious className="absolute -left-10 top-1/2 -translate-y-1/2 h-20 w-20 rounded-3xl border-none bg-card/40 backdrop-blur-2xl hover:bg-primary hover:text-white transition-all shadow-2xl opacity-0 group-hover/banner:opacity-100 group-hover/banner:left-8 duration-500" />
          <CarouselNext className="absolute -right-10 top-1/2 -translate-y-1/2 h-20 w-20 rounded-3xl border-none bg-card/40 backdrop-blur-2xl hover:bg-primary hover:text-white transition-all shadow-2xl opacity-0 group-hover/banner:opacity-100 group-hover/banner:right-8 duration-500" />
        </div>
      </Carousel>
      {/* Modern Pagination Dots */}
      <div className="flex justify-center items-center gap-4 mt-12">
        {apps.map((_, index) => (
          <button
            key={index}
            onClick={() => api?.scrollTo(index)}
            className={`transition-all duration-700 rounded-full ${
              current === index 
                ? "w-16 h-4 bg-primary shadow-2xl shadow-primary/60" 
                : "w-4 h-4 bg-muted-foreground/10 hover:bg-muted-foreground/30"
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
};
