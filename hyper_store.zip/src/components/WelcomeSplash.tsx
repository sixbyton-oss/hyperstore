import { useEffect, useState } from 'react';
import { HyperLogo } from './common/Brand';
import { useLanguage } from '@/contexts/LanguageContext';

interface WelcomeSplashProps {
  onComplete: () => void;
}

export function WelcomeSplash({ onComplete }: WelcomeSplashProps) {
  const [progress, setProgress] = useState(0);
  const { t } = useLanguage();

  useEffect(() => {
    const duration = 10000; // Changed to 10 seconds
    const interval = 50; // Update every 50ms
    const steps = duration / interval;
    const increment = 100 / steps;

    const timer = setInterval(() => {
      setProgress((prev) => {
        const next = prev + increment;
        if (next >= 100) {
          clearInterval(timer);
          setTimeout(onComplete, 300);
          return 100;
        }
        return next;
      });
    }, interval);

    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-br from-primary via-primary/90 to-secondary overflow-hidden">
      {/* Animated background particles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-white/20 rounded-full animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${5 + Math.random() * 10}s`
            }}
          />
        ))}
      </div>

      {/* Logo and brand animation */}
      <div className="relative z-10 flex flex-col items-center gap-8 animate-scale-in">
        <div className="animate-bounce-slow flex items-center justify-center pointer-events-none">
          <HyperLogo 
            className="w-[120vw] h-[120vw] md:w-[1500px] md:h-[1500px]" 
            noBackground 
            logoScale="scale-[5]" 
          />
        </div>
        
        <div className="text-center space-y-4">
          <h1 className="text-5xl md:text-7xl font-black text-white drop-shadow-lg animate-slide-up">
            {t('welcomeTitle')}
          </h1>
          <p className="text-xl md:text-2xl text-white/90 font-bold animate-slide-up animation-delay-300">
            {t('welcomeSubtitle')}
          </p>
        </div>

        {/* Rocket Animation */}
        <div className="relative w-full max-w-md h-24 mt-8 animate-slide-up animation-delay-600">
          {/* Track */}
          <div className="absolute top-1/2 left-0 right-0 h-1 bg-white/20 rounded-full -translate-y-1/2" />
          
          {/* Rocket */}
          <div 
            className="absolute top-1/2 -translate-y-1/2 transition-all duration-300 ease-linear"
            style={{ left: `${progress}%` }}
          >
            {/* Exhaust fire trail */}
            <div 
              className="absolute right-full top-1/2 -translate-y-1/2 h-8 bg-gradient-to-l from-orange-500 via-yellow-400 to-transparent rounded-l-full animate-pulse"
              style={{ 
                width: `${Math.min(progress * 2, 100)}px`,
                opacity: progress > 5 ? 1 : 0
              }}
            />
            
            {/* Rocket emoji */}
            <div className="text-6xl animate-bounce-slow filter drop-shadow-2xl">
              🚀
            </div>
          </div>
        </div>

        {/* Loading text */}
        <p className="text-white/80 text-sm font-semibold animate-pulse mt-8">
          {t('loadingApps')}
        </p>
      </div>
    </div>
  );
}
