import React from 'react';

export const HyperLogo: React.FC<{ className?: string, noBackground?: boolean, logoScale?: string }> = ({ className = "w-8 h-8", noBackground = false, logoScale = "scale-[2.5]" }) => {
  return (
    <div className={`relative flex items-center justify-center ${className} ${noBackground ? '' : 'overflow-hidden rounded-2xl shadow-2xl bg-card/50'}`}>
      <img 
        src="https://miaoda-conversation-file.s3cdn.medo.dev/user-a7ntqp350veo/conv-aefi7t2hyw3k/20260413/file-axrc4cwgcwlc.jpeg" 
        alt="Hyper Store Logo" 
        className={`w-full h-full object-contain transition-transform duration-500 hover:scale-[3] ${logoScale}`}
      />
    </div>
  );
};

export const HyperBrand: React.FC<{ size?: 'sm' | 'md' | 'lg', hideTextOnMobile?: boolean, className?: string }> = ({ size = 'md', hideTextOnMobile = false, className = "" }) => {
  const sizeClasses = {
    sm: "text-2xl whitespace-nowrap",
    md: "text-4xl whitespace-nowrap",
    lg: "text-6xl md:text-8xl whitespace-nowrap"
  };

  const logoSizes = {
    sm: "w-16 h-16",
    md: "w-48 h-48",
    lg: "w-80 h-80 md:w-[600px] md:h-[600px]"
  };

  return (
    <div className={`flex items-center gap-3 md:gap-4 ${className}`}>
      <HyperLogo className={logoSizes[size]} />
      <span className={`font-black tracking-tight italic ${sizeClasses[size]} bg-gradient-to-r from-primary via-primary/80 to-accent bg-clip-text text-transparent group-data-[collapsible=icon]:hidden ${hideTextOnMobile ? 'hidden md:block' : ''}`}>
        HYPER STORE
      </span>
    </div>
  );
};
