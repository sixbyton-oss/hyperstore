import { Loader2 } from 'lucide-react';

interface LoadingTransitionProps {
  message?: string;
}

export function LoadingTransition({ message = 'Loading...' }: LoadingTransitionProps) {
  return (
    <div className="fixed inset-0 z-40 flex flex-col items-center justify-center bg-background/80 backdrop-blur-md animate-fade-in">
      <div className="flex flex-col items-center gap-6 animate-scale-in">
        <div className="relative">
          <Loader2 className="w-16 h-16 text-primary animate-spin" />
          <div className="absolute inset-0 w-16 h-16 border-4 border-primary/20 rounded-full animate-ping" />
        </div>
        <p className="text-lg font-bold text-foreground animate-pulse">
          {message}
        </p>
      </div>
    </div>
  );
}
