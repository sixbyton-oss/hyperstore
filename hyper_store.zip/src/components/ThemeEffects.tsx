import React from 'react';
import { useTheme } from '@/contexts/ThemeContext';

export const ThemeEffects: React.FC = () => {
  const { theme } = useTheme();

  if (theme === 'christmas') {
    return (
      <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
        {/* Falling snow */}
        {[...Array(50)].map((_, i) => (
          <div
            key={`snow-${i}`}
            className="absolute w-2 h-2 bg-white rounded-full animate-snowfall opacity-80"
            style={{
              left: `${Math.random() * 100}%`,
              animationDuration: `${5 + Math.random() * 10}s`,
              animationDelay: `${Math.random() * 5}s`,
            }}
          />
        ))}
        
        {/* Christmas decorations */}
        <div className="absolute top-4 left-4 text-4xl animate-bounce-slow">🎄</div>
        <div className="absolute top-4 right-4 text-4xl animate-bounce-slow animation-delay-300">🎄</div>
        <div className="absolute bottom-20 left-8 text-3xl animate-sparkle">🎁</div>
        <div className="absolute bottom-20 right-8 text-3xl animate-sparkle animation-delay-600">🎁</div>
        <div className="absolute top-1/3 left-1/4 text-2xl animate-float">⭐</div>
        <div className="absolute top-1/2 right-1/4 text-2xl animate-float animation-delay-300">⭐</div>
      </div>
    );
  }

  if (theme === 'newyear') {
    return (
      <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
        {/* Fireworks */}
        {[...Array(20)].map((_, i) => (
          <div
            key={`firework-${i}`}
            className="absolute w-1 h-1 rounded-full animate-firework"
            style={{
              left: `${20 + Math.random() * 60}%`,
              top: `${20 + Math.random() * 40}%`,
              background: `hsl(${Math.random() * 360}, 100%, 60%)`,
              '--tx': `${(Math.random() - 0.5) * 200}px`,
              '--ty': `${(Math.random() - 0.5) * 200}px`,
              animationDelay: `${Math.random() * 3}s`,
            } as React.CSSProperties}
          />
        ))}
        
        {/* New Year decorations */}
        <div className="absolute top-8 left-1/4 text-5xl animate-bounce-slow">🎆</div>
        <div className="absolute top-8 right-1/4 text-5xl animate-bounce-slow animation-delay-300">🎇</div>
        <div className="absolute bottom-24 left-1/3 text-4xl animate-sparkle">🎉</div>
        <div className="absolute bottom-24 right-1/3 text-4xl animate-sparkle animation-delay-600">🎊</div>
        <div className="absolute top-1/2 left-12 text-3xl animate-float">✨</div>
        <div className="absolute top-1/3 right-12 text-3xl animate-float animation-delay-300">✨</div>
      </div>
    );
  }

  if (theme === 'summer') {
    return (
      <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
        {/* Floating summer elements */}
        {[...Array(15)].map((_, i) => (
          <div
            key={`summer-${i}`}
            className="absolute text-3xl animate-float opacity-60"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDuration: `${8 + Math.random() * 8}s`,
              animationDelay: `${Math.random() * 4}s`,
            }}
          >
            {['☀️', '🌊', '🏖️', '🌴', '🍉'][Math.floor(Math.random() * 5)]}
          </div>
        ))}
        
        {/* Summer decorations */}
        <div className="absolute top-8 right-8 text-6xl animate-bounce-slow">☀️</div>
        <div className="absolute bottom-24 left-8 text-4xl animate-sparkle">🌴</div>
        <div className="absolute bottom-24 right-12 text-4xl animate-sparkle animation-delay-600">🏖️</div>
        <div className="absolute top-1/3 left-1/4 text-3xl animate-float">🦋</div>
        <div className="absolute top-1/2 right-1/4 text-3xl animate-float animation-delay-300">🌺</div>
      </div>
    );
  }

  return null;
};
