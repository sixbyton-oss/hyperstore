import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { SidebarProvider } from '@/components/ui/sidebar';
import { AppSidebar } from './AppSidebar';
import { Toaster } from '@/components/ui/sonner';
import { BottomNav } from './BottomNav';
import { HyperBrand } from '../common/Brand';
import { ThemeEffects } from '../ThemeEffects';
import { useTheme } from '@/contexts/ThemeContext';
import { Menu } from 'lucide-react';
import { Button } from '../ui/button';
import { useSidebar } from '../ui/sidebar';
import { LoadingTransition } from '../LoadingTransition';

const CustomSidebarTrigger = () => {
  const { toggleSidebar } = useSidebar();
  return (
    <Button
      variant="ghost"
      size="icon"
      className="md:hidden click-effect"
      onClick={toggleSidebar}
    >
      <Menu className="w-8 h-8 stroke-[3]" />
    </Button>
  );
};

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const { theme } = useTheme();
  const [isNavigating, setIsNavigating] = useState(false);
  const [prevPath, setPrevPath] = useState(location.pathname);

  useEffect(() => {
    if (location.pathname !== prevPath) {
      setIsNavigating(true);
      const timer = setTimeout(() => {
        setIsNavigating(false);
        setPrevPath(location.pathname);
      }, 1500); // Increased from 600ms to 1500ms (1.5 seconds)
      return () => clearTimeout(timer);
    }
  }, [location.pathname, prevPath]);

  // Themed background styles for entire site
  const getBackgroundStyle = () => {
    if (theme === 'summer') {
      return 'bg-gradient-to-br from-yellow-100 via-orange-50 to-cyan-100';
    }
    if (theme === 'christmas') {
      return 'bg-gradient-to-br from-slate-800 via-slate-700 to-slate-900';
    }
    return 'bg-background';
  };

  return (
    <SidebarProvider>
      {isNavigating && <LoadingTransition message="Loading..." />}
      <ThemeEffects />
      <div className={`flex min-h-screen w-full pb-16 md:pb-0 ${getBackgroundStyle()}`}>
        <AppSidebar />
        <main className="flex-1 overflow-auto">
          <div className="flex h-40 items-center border-b px-4 md:hidden glass-effect sticky top-0 z-40">
            <CustomSidebarTrigger />
            <div className="ml-4">
              <HyperBrand size="sm" />
            </div>
          </div>
          <div className="p-4 md:p-8 max-w-[1600px] mx-auto">
            {children}
          </div>
        </main>
      </div>
      <BottomNav />
      <Toaster />
    </SidebarProvider>
  );
};
