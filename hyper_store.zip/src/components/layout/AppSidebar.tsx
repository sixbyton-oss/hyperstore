import React from 'react';
import { Home, Gamepad2, LayoutGrid, Search, User, Settings, Download } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  useSidebar,
} from '@/components/ui/sidebar';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useProfile } from '@/contexts/ProfileContext';
import { HyperBrand } from '../common/Brand';

const menuItems = [
  { name: 'Home', path: '/', icon: Home },
  { name: 'Mod APKs', path: '/mod-apks', icon: LayoutGrid },
  { name: 'TikTok⬆️', path: '/tiktok', icon: Download },
  { name: 'Search', path: '/search', icon: Search },
  { name: 'Profile', path: '/profile', icon: User },
  { name: 'Settings', path: '/settings', icon: Settings },
];

export const AppSidebar: React.FC = () => {
  const location = useLocation();
  const { profile } = useProfile();
  const { setOpenMobile } = useSidebar();

  const handleLinkClick = () => {
    // Close sidebar on mobile after navigation
    setOpenMobile(false);
  };

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="p-4 border-b space-y-4">
        <div className="flex items-center gap-3 font-bold group-data-[collapsible=icon]:justify-center min-w-0">
          <HyperBrand size="sm" />
        </div>
        
        <div className="flex items-center gap-3 py-2 group-data-[collapsible=icon]:justify-center">
          <Avatar className="w-8 h-8 shrink-0">
            <AvatarImage src={profile.avatar} />
            <AvatarFallback className="bg-primary/10 text-primary text-xs font-black">
              {profile.name?.[0]?.toUpperCase() || 'U'}
            </AvatarFallback>
          </Avatar>
          <div className="flex flex-col group-data-[collapsible=icon]:hidden overflow-hidden">
            <span className="text-sm font-bold truncate">{profile.name || 'Guest User'}</span>
            <span className="text-[10px] text-muted-foreground truncate uppercase tracking-tighter">
              {profile.email ? 'Member' : 'Get Started'}
            </span>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent className="py-4">
        <SidebarMenu>
          {menuItems.map((item) => (
            <SidebarMenuItem key={item.name}>
              <SidebarMenuButton
                asChild
                isActive={location.pathname === item.path}
                tooltip={item.name}
                className="click-effect"
              >
                <Link to={item.path} className="flex items-center gap-3 w-full" onClick={handleLinkClick}>
                  <item.icon className="w-5 h-5" />
                  <span>{item.name}</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
    </Sidebar>
  );
};
