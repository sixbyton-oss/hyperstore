import React from 'react';
import { Home, Gamepad2, LayoutGrid, Settings, Download } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';

const navItems = [
  { name: 'Home', path: '/', icon: Home },
  { name: 'Mod APKs', path: '/mod-apks', icon: LayoutGrid },
  { name: 'TikTok', path: '/tiktok', icon: Download },
  { name: 'Settings', path: '/settings', icon: Settings },
];

export const BottomNav: React.FC = () => {
  const location = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 h-16 md:hidden bg-card border-t border-border flex items-center justify-around z-50 px-4 pb-safe shadow-[0_-4px_20px_rgba(0,0,0,0.1)]">
      {navItems.map((item) => {
        const isActive = location.pathname === item.path;
        return (
          <Link
            key={item.name}
            to={item.path}
            className={cn(
              "flex flex-col items-center gap-1 min-w-[64px] transition-all duration-300 click-effect",
              isActive ? "text-primary scale-110" : "text-muted-foreground"
            )}
          >
            <div className={cn(
              "p-1 rounded-full transition-colors",
              isActive && "bg-primary/10"
            )}>
              <item.icon className={cn("w-6 h-6", isActive && "fill-current")} />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-widest">{item.name}</span>
          </Link>
        );
      })}
    </nav>
  );
};
