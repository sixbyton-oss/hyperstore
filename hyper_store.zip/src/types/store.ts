export interface AppInfo {
  id: string;
  name: string;
  category: 'game' | 'app' | 'tool';
  tagline: string;
  description: string;
  icon?: string;
  screenshots: string[];
  downloadUrl: string;
  isFeatured?: boolean;
  color?: string;
  size?: string;
  version?: string;
  updatedAt?: string;
}

export interface UserProfile {
  name: string;
  email: string;
  avatar: string;
}
