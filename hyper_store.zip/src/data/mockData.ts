import { AppInfo } from '../types/store';

export const mockApps: AppInfo[] = [
  {
    id: 'tiktok-downloader',
    name: 'TikTok Downloader',
    category: 'tool',
    tagline: 'Download TikTok Videos Without Watermark',
    description: 'The best online TikTok video downloader. Fast, free, and without watermarks. Download videos in high quality MP4 or convert to MP3 audio.',
    icon: 'https://miaoda-conversation-file.s3cdn.medo.dev/user-a7ntqp350veo/conv-aefi7t2hyw3k/20260414/file-axxds4b3lc74.png',
    color: 'bg-black',
    screenshots: [],
    downloadUrl: '/tiktok', // Special case: redirect to internal page
    isFeatured: true,
    size: '12 MB',
    version: '1.0.0',
    updatedAt: 'Mar 20, 2026'
  },
  {
    id: 'freefire-mod',
    name: 'Free Fire MOD APK',
    category: 'game',
    tagline: 'Unlimited Diamonds',
    description: 'Free Fire is the ultimate survival shooter game available on mobile. Each 10-minute game places you on a remote island where you are pit against 49 other players, all seeking survival. Players freely choose their starting point with their parachute, and aim to stay in the safe zone for as long as possible. Drive vehicles to explore the vast map, hide in wild, or become invisible by proning under grass or rifts. Ambush, snipe, survive, there is only one goal: to survive and answer the call of duty.',
    icon: 'https://miaoda-conversation-file.s3cdn.medo.dev/user-a7ntqp350veo/conv-aefi7t2hyw3k/20260321/file-aeitfwyunhts.jpeg',
    color: 'bg-orange-600',
    screenshots: [],
    downloadUrl: 'https://cdn800.onehost.io/2023/Free_Fire_1.122.1_1772542732_latestmodapks.com.xapk',
    isFeatured: true,
    size: '371 MB',
    version: '1.122.1',
    updatedAt: 'Mar 20, 2026'
  }
];

export const featuredApps = mockApps.filter(app => app.isFeatured).slice(0, 4);
export const games = mockApps.filter(app => app.category === 'game');
export const apps = mockApps.filter(app => app.category === 'app');
export const tools = mockApps.filter(app => app.category === 'tool');
