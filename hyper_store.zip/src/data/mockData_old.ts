import { AppInfo } from '../types/store';

export const mockApps: AppInfo[] = [
  {
    id: 'freefire-mod',
    name: 'Free Fire MOD APK',
    category: 'game',
    tagline: 'Unlimited Diamonds',
    description: 'Free Fire is the ultimate survival shooter game available on mobile. Each 10-minute game places you on a remote island where you are pit against 49 other players, all seeking survival. Players freely choose their starting point with their parachute, and aim to stay in the safe zone for as long as possible. Drive vehicles to explore the vast map, hide in wild, or become invisible by proning under grass or rifts. Ambush, snipe, survive, there is only one goal: to survive and answer the call of duty.',
    icon: 'https://miaoda-conversation-file.s3cdn.medo.dev/user-a7ntqp350veo/conv-aefi7t2hyw3k/20260321/file-aeitfwyunhts.jpeg',
    color: 'bg-orange-600',
    screenshots: [],
    downloadUrl: 'https://cdn800.onehost.io/2023/Free_Fire_1.122.1_1772542732_latestmodapks.com.xapk',
    isFeatured: true,
    size: '371 MB',
    version: '1.122.1',
    updatedAt: 'Mar 20, 2026'
  },
  {
    id: 'g1',
    name: 'Cyber Strike',
    category: 'game',
    tagline: 'Futuristic fast-paced shooter',
    description: 'Cyber Strike is an adrenaline-pumping shooter set in a neon-lit future. Battle across 10 distinct districts, upgrade your cybernetics, and become the ultimate street legend.',
    icon: '',
    color: 'bg-violet-500',
    screenshots: [],
    downloadUrl: '#',
    isFeatured: false
  },
  {
    id: 'g2',
    name: 'Dragon Quest',
    category: 'game',
    tagline: 'Epic fantasy adventure',
    description: 'Embark on a journey through the mystical lands of Eldoria. Solve puzzles, defeat ancient dragons, and restore peace to the kingdom in this breathtaking RPG.',
    icon: '',
    color: 'bg-orange-500',
    screenshots: [],
    downloadUrl: '#',
    isFeatured: false
  },
  {
    id: 'a1',
    name: 'Sky Notes',
    category: 'app',
    tagline: 'Organize your thoughts in the cloud',
    description: 'Sky Notes is the ultimate productivity companion. Sync your notes across all devices, collaborate in real-time, and stay organized with ease.',
    icon: '',
    color: 'bg-blue-500',
    screenshots: [],
    downloadUrl: '#',
    isFeatured: false
  },
  {
    id: 'a2',
    name: 'Zen Fit',
    category: 'app',
    tagline: 'Mindful exercise for a better you',
    description: 'Balance your body and mind with Zen Fit. Personalized yoga routines, meditation sessions, and progress tracking designed for every fitness level.',
    icon: '',
    color: 'bg-emerald-500',
    screenshots: [],
    downloadUrl: '#',
    isFeatured: false
  },
  // 12 Games total
  { id: 'g3', name: 'Racer X', category: 'game', tagline: 'High-speed street racing', description: 'Experience the thrill of underground racing with Racer X. Customize your car and dominate the streets.', icon: '', color: 'bg-red-500', screenshots: [], downloadUrl: '#' },
  { id: 'g4', name: 'Puzzle Master', category: 'game', tagline: 'Sharpen your mind', description: 'Thousands of challenging puzzles that will test your logic and patience.', icon: '', color: 'bg-indigo-500', screenshots: [], downloadUrl: '#' },
  { id: 'g5', name: 'Shadow Ninja', category: 'game', tagline: 'Become a shadow warrior', description: 'Master the arts of stealth and combat in this action-packed ninja simulator.', icon: '', color: 'bg-slate-800', screenshots: [], downloadUrl: '#' },
  { id: 'g6', name: 'Galaxy Defender', category: 'game', tagline: 'Save the universe', description: 'Blast your way through waves of alien invaders in this classic arcade-style shooter.', icon: '', color: 'bg-indigo-900', screenshots: [], downloadUrl: '#' },
  { id: 'g7', name: 'Farm Village', category: 'game', tagline: 'Build your dream farm', description: 'Plant crops, raise animals, and build the most successful farm in the countryside.', icon: '', color: 'bg-green-500', screenshots: [], downloadUrl: '#' },
  { id: 'g8', name: 'Chess Titans', category: 'game', tagline: 'Master the board', description: 'The most advanced chess simulation for players of all skill levels.', icon: '', color: 'bg-stone-500', screenshots: [], downloadUrl: '#' },
  { id: 'g9', name: 'Ocean Quest', category: 'game', tagline: 'Explore the deep sea', description: 'Discover hidden treasures and ancient mysteries in the vast depths of the ocean.', icon: '', color: 'bg-cyan-500', screenshots: [], downloadUrl: '#' },
  { id: 'g10', name: 'Battle Arena', category: 'game', tagline: 'Ultimate multiplayer combat', description: 'Team up with friends and compete in intense 5v5 battles.', icon: '', color: 'bg-rose-500', screenshots: [], downloadUrl: '#' },
  { id: 'g11', name: 'Zombie Run', category: 'game', tagline: 'Survive the apocalypse', description: 'Run for your life in a world overrun by the undead.', icon: '', color: 'bg-lime-800', screenshots: [], downloadUrl: '#' },
  { id: 'g12', name: 'City Tycoon', category: 'game', tagline: 'Build your metropolis', description: 'Manage resources and grow your small town into a bustling mega-city.', icon: '', color: 'bg-yellow-600', screenshots: [], downloadUrl: '#' },
  // 12 Apps total
  { id: 'a3', name: 'Weather Now', category: 'app', tagline: 'Accurate local weather', description: 'Get real-time weather updates, radar maps, and severe weather alerts.', icon: '', color: 'bg-sky-400', screenshots: [], downloadUrl: '#' },
  { id: 'a4', name: 'Safe Wallet', category: 'app', tagline: 'Secure your finances', description: 'Track your spending, set budgets, and manage your money with top-tier security.', icon: '', color: 'bg-teal-500', screenshots: [], downloadUrl: '#' },
  { id: 'a5', name: 'Art Studio', category: 'app', tagline: 'Unleash your creativity', description: 'Professional-grade digital painting tools for artists on the go.', icon: '', color: 'bg-purple-500', screenshots: [], downloadUrl: '#' },
  { id: 'a6', name: 'Language Pro', category: 'app', tagline: 'Learn a new language', description: 'Master a new language in just minutes a day with our scientifically proven methods.', icon: '', color: 'bg-orange-400', screenshots: [], downloadUrl: '#' },
  { id: 'a7', name: 'Foodie Guide', category: 'app', tagline: 'Discover best restaurants', description: 'Find the best places to eat near you with reviews from a global community of foodies.', icon: '', color: 'bg-red-400', screenshots: [], downloadUrl: '#' },
  { id: 'a8', name: 'Video Edit', category: 'app', tagline: 'Easy video editing', description: 'Create stunning videos with professional filters, transitions, and effects.', icon: '', color: 'bg-fuchsia-500', screenshots: [], downloadUrl: '#' },
  { id: 'a9', name: 'Code Master', category: 'app', tagline: 'Learn to code anywhere', description: 'Interactive coding lessons for Python, JavaScript, and more.', icon: '', color: 'bg-neutral-800', screenshots: [], downloadUrl: '#' },
  { id: 'a10', name: 'Health Mate', category: 'app', tagline: 'Your health, our priority', description: 'Track your steps, heart rate, and sleep quality for a healthier life.', icon: '', color: 'bg-rose-400', screenshots: [], downloadUrl: '#' },
  { id: 'a11', name: 'Social Connect', category: 'app', tagline: 'Stay in touch', description: 'Connect with friends and family across the globe with high-quality video calls.', icon: '', color: 'bg-indigo-600', screenshots: [], downloadUrl: '#' },
  { id: 'a12', name: 'Quick Scan', category: 'app', tagline: 'PDF scanner in your pocket', description: 'Scan documents, receipts, and photos to high-quality PDF files instantly.', icon: '', color: 'bg-zinc-500', screenshots: [], downloadUrl: '#' },
];

export const featuredApps = mockApps.filter(app => app.isFeatured).slice(0, 4);
export const games = mockApps.filter(app => app.category === 'game');
export const apps = mockApps.filter(app => app.category === 'app');
