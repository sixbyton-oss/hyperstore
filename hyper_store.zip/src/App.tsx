import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import IntersectObserver from '@/components/common/IntersectObserver';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { ProfileProvider } from '@/contexts/ProfileContext';
import { LanguageProvider } from '@/contexts/LanguageContext';
import { Layout } from '@/components/layout/Layout';
import { WelcomeSplash } from '@/components/WelcomeSplash';
import routes from './routes';

const App: React.FC = () => {
  const [showSplash, setShowSplash] = useState(true); // Always show splash on app load

  const handleSplashComplete = () => {
    setShowSplash(false);
  };

  if (showSplash) {
    return (
      <LanguageProvider>
        <ThemeProvider>
          <WelcomeSplash onComplete={handleSplashComplete} />
        </ThemeProvider>
      </LanguageProvider>
    );
  }

  return (
    <LanguageProvider>
      <ThemeProvider>
        <ProfileProvider>
          <Router>
            <IntersectObserver />
            <Layout>
              <Routes>
                {routes.map((route, index) => (
                  <Route
                    key={index}
                    path={route.path}
                    element={route.element}
                  />
                ))}
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </Layout>
          </Router>
        </ProfileProvider>
      </ThemeProvider>
    </LanguageProvider>
  );
};

export default App;
