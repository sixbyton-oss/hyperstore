const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { url, filename } = await req.json();

    if (!url) {
      return new Response(
        JSON.stringify({ error: 'URL is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch the video from TikTok
    const videoResponse = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
    });

    if (!videoResponse.ok) {
      throw new Error(`Failed to fetch video: ${videoResponse.status}`);
    }

    // Get the video content
    const videoBlob = await videoResponse.blob();

    // Return the video with proper headers to force download
    return new Response(videoBlob, {
      headers: {
        ...corsHeaders,
        'Content-Type': videoResponse.headers.get('Content-Type') || 'video/mp4',
        'Content-Disposition': `attachment; filename="${filename || 'tiktok_video.mp4'}"`,
        'Content-Length': videoBlob.size.toString(),
      },
    });

  } catch (error) {
    console.error('Download proxy error:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Failed to download video' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
