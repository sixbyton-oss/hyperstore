import { createClient } from 'jsr:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface TikTokRequest {
  url: string;
  hd?: boolean;
}

interface TikTokAPIResponse {
  code: number;
  msg: string;
  processed_time: number;
  data?: {
    id: string;
    title: string;
    play: string;
    wmplay: string;
    hdplay: string;
    music: string;
    cover: string;
    duration: number;
    author: {
      unique_id: string;
      nickname: string;
      avatar: string;
    };
  };
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { url, hd = false }: TikTokRequest = await req.json();

    // Validate URL
    if (!url || !url.includes('tiktok.com')) {
      return new Response(
        JSON.stringify({ 
          error: 'Invalid TikTok URL. Please provide a valid TikTok video link.' 
        }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Build API URL
    const apiUrl = `https://www.tikwm.com/api/?url=${encodeURIComponent(url)}${hd ? '&hd=1' : ''}`;

    // Fetch from TikWM API
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
    });

    if (!response.ok) {
      throw new Error(`TikWM API returned status ${response.status}`);
    }

    const data: TikTokAPIResponse = await response.json();

    // Check if API returned error
    if (data.code !== 0) {
      return new Response(
        JSON.stringify({ 
          error: data.msg || 'Failed to fetch video. Please check the URL and try again.' 
        }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Return successful response
    return new Response(
      JSON.stringify({
        success: true,
        data: {
          id: data.data?.id,
          title: data.data?.title,
          videoUrl: data.data?.play, // No watermark
          hdVideoUrl: data.data?.hdplay, // HD quality
          watermarkVideoUrl: data.data?.wmplay, // With watermark
          audioUrl: data.data?.music, // MP3 audio
          coverImage: data.data?.cover,
          duration: data.data?.duration,
          author: data.data?.author,
        },
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('TikTok download error:', error);
    return new Response(
      JSON.stringify({ 
        error: error.message || 'Failed to process request. Please try again.' 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});
